/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include <vector>
using namespace std;

class Account {
public:
    int accNo;
    string name;
    double balance;

    void createAccount() {
        cout << "Enter Account Number: ";
        cin >> accNo;

        cout << "Enter Name: ";
        cin >> name;

        cout << "Enter Initial Balance: ";
        cin >> balance;
    }

    void display() {
        cout << "\nAccount No: " << accNo;
        cout << "\nName: " << name;
        cout << "\nBalance: " << balance << endl;
    }
};

vector<Account> accounts;

void createAccount() {
    Account a;
    a.createAccount();
    accounts.push_back(a);
    cout << "Account Created Successfully!\n";
}

void depositMoney() {
    int acc;
    double amount;

    cout << "Enter Account Number: ";
    cin >> acc;

    for (int i = 0; i < accounts.size(); i++) {
        if (accounts[i].accNo == acc) {
            cout << "Enter Amount to Deposit: ";
            cin >> amount;

            accounts[i].balance += amount;

            cout << "Deposit Successful!\n";
            return;
        }
    }

    cout << "Account Not Found!\n";
}

void withdrawMoney() {
    int acc;
    double amount;

    cout << "Enter Account Number: ";
    cin >> acc;

    for (int i = 0; i < accounts.size(); i++) {
        if (accounts[i].accNo == acc) {
            cout << "Enter Amount to Withdraw: ";
            cin >> amount;

            if (amount <= accounts[i].balance) {
                accounts[i].balance -= amount;
                cout << "Withdrawal Successful!\n";
            } else {
                cout << "Insufficient Balance!\n";
            }
            return;
        }
    }

    cout << "Account Not Found!\n";
}

void checkBalance() {
    int acc;

    cout << "Enter Account Number: ";
    cin >> acc;

    for (int i = 0; i < accounts.size(); i++) {
        if (accounts[i].accNo == acc) {
            cout << "Current Balance: " << accounts[i].balance << endl;
            return;
        }
    }

    cout << "Account Not Found!\n";
}

int main() {
    int choice;

    do {
        cout << "\n===== BANK MANAGEMENT SYSTEM =====\n";
        cout << "1. Create Account\n";
        cout << "2. Deposit Money\n";
        cout << "3. Withdraw Money\n";
        cout << "4. Check Balance\n";
        cout << "5. Exit\n";

        cout << "Enter Choice: ";
        cin >> choice;

        switch (choice) {
            case 1:
                createAccount();
                break;

            case 2:
                depositMoney();
                break;

            case 3:
                withdrawMoney();
                break;

            case 4:
                checkBalance();
                break;

            case 5:
                cout << "Thank You!\n";
                break;

            default:
                cout << "Invalid Choice!\n";
        }

    } while (choice != 5);

    return 0;
}