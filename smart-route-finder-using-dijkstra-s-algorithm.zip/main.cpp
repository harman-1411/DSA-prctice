/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include <vector>
#include <queue>
#include <climits>

using namespace std;

void dijkstra(int source, vector<vector<pair<int,int>>>& graph, int n) {

    vector<int> dist(n, INT_MAX);
    priority_queue<
        pair<int,int>,
        vector<pair<int,int>>,
        greater<pair<int,int>>
    > pq;

    dist[source] = 0;
    pq.push({0, source});

    while(!pq.empty()) {

        int currentDist = pq.top().first;
        int node = pq.top().second;
        pq.pop();

        for(auto edge : graph[node]) {

            int nextNode = edge.first;
            int weight = edge.second;

            if(dist[node] + weight < dist[nextNode]) {

                dist[nextNode] = dist[node] + weight;

                pq.push({dist[nextNode], nextNode});
            }
        }
    }

    cout << "\nShortest Distance from City "
         << source << ":\n";

    for(int i = 0; i < n; i++) {
        cout << "To City " << i
             << " = " << dist[i] << endl;
    }
}

int main() {

    int cities, roads;

    cout << "Enter Number of Cities: ";
    cin >> cities;

    vector<vector<pair<int,int>>> graph(cities);

    cout << "Enter Number of Roads: ";
    cin >> roads;

    cout << "\nEnter: City1 City2 Distance\n";

    for(int i = 0; i < roads; i++) {

        int u, v, w;
        cin >> u >> v >> w;

        graph[u].push_back({v, w});
        graph[v].push_back({u, w});
    }

    int source;

    cout << "\nEnter Source City: ";
    cin >> source;

    dijkstra(source, graph, cities);

    return 0;
}